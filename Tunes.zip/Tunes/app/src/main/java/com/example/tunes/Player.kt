package com.example.tunes

import android.content.Context
import android.media.audiofx.Equalizer
import androidx.annotation.OptIn
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

@OptIn(UnstableApi::class)
object PlayerHolder {
    lateinit var player: ExoPlayer
    var eq: Equalizer? = null
    val levels = HashMap<Int, Short>()

    fun init(c: Context) {
        if (::player.isInitialized) return
        // Float PCM output keeps 24/32-bit sources un-truncated (hi-res path).
        val rf = object : DefaultRenderersFactory(c) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink =
                DefaultAudioSink.Builder(context).setEnableFloatOutput(true)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams).build()
        }
        player = ExoPlayer.Builder(c, rf)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            .setHandleAudioBecomingNoisy(true).build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = attach(audioSessionId)
        })
        attach(player.audioSessionId)
    }

    fun attach(id: Int) {
        eq?.release()
        eq = if (id == 0) null else try {
            Equalizer(0, id).apply {
                enabled = true
                levels.forEach { (b, l) -> if (b < numberOfBands) setBandLevel(b.toShort(), l) }
            }
        } catch (e: Exception) { null }
    }
}

@OptIn(UnstableApi::class)
class PlayerService : MediaSessionService() {
    private var session: MediaSession? = null
    override fun onCreate() {
        super.onCreate(); PlayerHolder.init(this)
        session = MediaSession.Builder(this, PlayerHolder.player).build()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session
    override fun onDestroy() { session?.release(); super.onDestroy() }
}
