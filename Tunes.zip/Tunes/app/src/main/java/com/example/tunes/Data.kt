package com.example.tunes

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.*

data class Song(val id: Long, val title: String, val artist: String, val album: String, val albumId: Long, val durationMs: Long, val uri: Uri)
data class LyricLine(val ms: Long, val text: String)

fun loadSongs(c: Context): List<Song> {
    val out = mutableListOf<Song>()
    val M = MediaStore.Audio.Media
    val proj = arrayOf(M._ID, M.TITLE, M.ARTIST, M.ALBUM, M.ALBUM_ID, M.DURATION)
    c.contentResolver.query(M.EXTERNAL_CONTENT_URI, proj, "${M.IS_MUSIC}!=0", null, "${M.TITLE} COLLATE NOCASE")?.use { q ->
        while (q.moveToNext()) {
            val id = q.getLong(0)
            out += Song(id, q.getString(1) ?: "Unknown", q.getString(2) ?: "Unknown Artist", q.getString(3) ?: "Unknown Album",
                q.getLong(4), q.getLong(5), Uri.withAppendedPath(M.EXTERNAL_CONTENT_URI, id.toString()))
        }
    }
    return out
}

/** Full-resolution album art: embedded picture first, then system thumbnail. */
object Art {
    private val cache = LruCache<String, Bitmap>(30)
    fun load(c: Context, s: Song, px: Int): Bitmap? {
        val key = "${s.id}_$px"
        cache.get(key)?.let { return it }
        var bmp: Bitmap? = try {
            val r = MediaMetadataRetriever(); r.setDataSource(c, s.uri)
            val b = r.embeddedPicture; r.release(); b?.let { decode(it, px) }
        } catch (e: Exception) { null }
        if (bmp == null && Build.VERSION.SDK_INT >= 29)
            bmp = try { c.contentResolver.loadThumbnail(s.uri, Size(px, px), null) } catch (e: Exception) { null }
        bmp?.let { cache.put(key, it) }
        return bmp
    }
    private fun decode(b: ByteArray, px: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1; while (o.outWidth / (s * 2) >= px) s *= 2
        return BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
    }
}

/** Auto-downloads synced lyrics from LRCLIB and caches them on device. */
object Lyrics {
    suspend fun get(c: Context, s: Song): List<LyricLine> = withContext(Dispatchers.IO) {
        val f = File(c.filesDir, "lyr_${s.id}.txt")
        var raw = if (f.exists()) f.readText() else ""
        if (raw.isBlank()) { raw = fetch(s) ?: ""; if (raw.isNotBlank()) f.writeText(raw) }
        parse(raw)
    }
    private fun enc(x: String) = URLEncoder.encode(x, "UTF-8")
    private fun fetch(s: Song): String? = try {
        val q = "artist_name=${enc(s.artist)}&track_name=${enc(s.title)}&album_name=${enc(s.album)}&duration=${s.durationMs / 1000}"
        val con = URL("https://lrclib.net/api/get?$q").openConnection() as HttpURLConnection
        con.setRequestProperty("User-Agent", "Tunes/1.0"); con.connectTimeout = 8000; con.readTimeout = 8000
        if (con.responseCode != 200) null else {
            val j = JSONObject(con.inputStream.bufferedReader().readText())
            fun f(k: String) = if (j.isNull(k)) "" else j.getString(k)
            f("syncedLyrics").ifBlank { f("plainLyrics") }
        }
    } catch (e: Exception) { null }
    private val re = Regex("""\[(\d+):(\d+)(?:[.:](\d+))?]""")
    private fun parse(raw: String): List<LyricLine> = raw.lines().mapNotNull { l ->
        val m = re.find(l)
        if (m == null) l.trim().takeIf { it.isNotEmpty() }?.let { LyricLine(-1, it) }
        else {
            val g = m.groupValues
            val ms = g[1].toLong() * 60000 + g[2].toLong() * 1000 + ((g[3] + "00").take(3)).toLong()
            LyricLine(ms, l.substring(m.range.last + 1).trim())
        }
    }
}
