package com.example.tunes

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.media.audiofx.Visualizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.media3.common.*
import kotlinx.coroutines.*
import kotlin.math.hypot
import kotlin.math.max

val Accent = Color(0xFFFA2D48)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PlayerHolder.init(applicationContext)
        startService(Intent(this, PlayerService::class.java))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Color.Black, surface = Color(0xFF0B0B0D))) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

fun playAll(list: List<Song>, i: Int) {
    val p = PlayerHolder.player
    p.setMediaItems(list.map {
        MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri).setMediaMetadata(
            MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).setAlbumTitle(it.album).build()).build()
    }, i, 0)
    p.prepare(); p.play()
}

@Composable
fun App() {
    val c = LocalContext.current
    val p = PlayerHolder.player
    var songs by remember { mutableStateOf(emptyList<Song>()) }
    val songsNow by rememberUpdatedState(songs)
    var cur by remember { mutableStateOf<Song?>(null) }
    var playing by remember { mutableStateOf(p.isPlaying) }
    var tab by remember { mutableIntStateOf(0) }
    var full by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    LaunchedEffect(Unit) {
        val l = mutableListOf(
            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        perm.launch(l.toTypedArray())
    }
    LaunchedEffect(refresh) { if (refresh > 0) songs = withContext(Dispatchers.IO) { loadSongs(c) } }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(m: MediaItem?, r: Int) {
                val id = m?.mediaId?.toLongOrNull(); cur = songsNow.find { it.id == id }
            }
        }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    BackHandler(full) { full = false }

    Box(Modifier.fillMaxSize()) {
        Scaffold(bottomBar = {
            Column {
                cur?.let { s ->
                    Row(Modifier.fillMaxWidth().background(Color(0xFF1C1C1E)).clickable { full = true }.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        ArtImage(s, 128, Modifier.size(44.dp))
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(s.title, maxLines = 1); Text(s.artist, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        IconButton({ if (playing) p.pause() else p.play() }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null) }
                        IconButton({ p.seekToNextMediaItem() }) { Icon(Icons.Filled.SkipNext, null) }
                    }
                }
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.MusicNote, null) }, label = { Text("Songs") })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Album, null) }, label = { Text("Albums") })
                }
            }
        }) { pad ->
            if (songs.isEmpty()) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("No music found. Grant access to audio files.", textAlign = TextAlign.Center) }
            else if (tab == 0) LazyColumn(Modifier.padding(pad)) {
                itemsIndexed(songs) { i, s ->
                    Row(Modifier.fillMaxWidth().clickable { playAll(songs, i) }.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ArtImage(s, 128, Modifier.size(52.dp))
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(s.title, maxLines = 1); Text("${s.artist} · ${s.album}", maxLines = 1, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }
            } else {
                val albums = remember(songs) { songs.groupBy { it.albumId }.values.toList() }
                LazyVerticalGrid(GridCells.Adaptive(150.dp), Modifier.padding(pad), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(albums) { a ->
                        Column(Modifier.clickable { playAll(a, 0) }) {
                            ArtImage(a[0], 512, Modifier.fillMaxWidth().aspectRatio(1f))
                            Text(a[0].album, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
                            Text(a[0].artist, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }
            }
        }
        val s = cur
        if (full && s != null) NowPlaying(s, playing) { full = false }
    }
}

@Composable
fun ArtImage(s: Song, px: Int, mod: Modifier) {
    val c = LocalContext.current
    val bmp by produceState<Bitmap?>(null, s.id, px) { value = withContext(Dispatchers.IO) { Art.load(c, s, px) } }
    Box(mod.clip(RoundedCornerShape(8.dp)).background(Color(0xFF2A2A2E))) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = FilterQuality.High) }
            ?: Icon(Icons.Filled.MusicNote, null, Modifier.align(Alignment.Center), tint = Color.Gray)
    }
}

@Composable
fun NowPlaying(s: Song, playing: Boolean, onClose: () -> Unit) {
    val p = PlayerHolder.player
    var mode by remember { mutableIntStateOf(0) }
    var eqOpen by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    LaunchedEffect(s.id) { while (true) { pos = p.currentPosition; delay(200) } }
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B0D)).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, null) }
            Spacer(Modifier.weight(1f))
            IconButton({ eqOpen = true }) { Icon(Icons.Filled.Equalizer, null) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Art", "Lyrics", "Visualizer").forEachIndexed { i, t -> FilterChip(mode == i, { mode = i }, { Text(t) }) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 16.dp), Alignment.Center) {
            when (mode) {
                0 -> ArtImage(s, 1600, Modifier.fillMaxWidth().aspectRatio(1f))
                1 -> LyricsView(s, pos)
                else -> Spectrum()
            }
        }
        Text(s.title, style = MaterialTheme.typography.headlineSmall, maxLines = 1)
        Text(s.artist, color = Accent, maxLines = 1)
        Slider(pos.toFloat(), { pos = it.toLong(); p.seekTo(pos) }, valueRange = 0f..max(s.durationMs, 1L).toFloat())
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            IconButton({ p.seekToPreviousMediaItem() }) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(36.dp)) }
            FilledIconButton({ if (playing) p.pause() else p.play() }, Modifier.size(64.dp)) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(36.dp))
            }
            IconButton({ p.seekToNextMediaItem() }) { Icon(Icons.Filled.SkipNext, null, Modifier.size(36.dp)) }
        }
    }
    if (eqOpen) EqDialog { eqOpen = false }
}

@Composable
fun LyricsView(s: Song, pos: Long) {
    val c = LocalContext.current
    val lines by produceState<List<LyricLine>?>(null, s.id) { value = Lyrics.get(c, s) }
    val l = lines
    val st = rememberLazyListState()
    val idx = l?.indexOfLast { it.ms in 0..pos } ?: -1
    LaunchedEffect(idx) { if (idx >= 0) st.animateScrollToItem(max(idx - 2, 0)) }
    when {
        l == null -> Text("Fetching lyrics…", color = Color.Gray)
        l.isEmpty() -> Text("No lyrics found for this song.", color = Color.Gray)
        else -> LazyColumn(state = st, modifier = Modifier.fillMaxSize()) {
            itemsIndexed(l) { i, ln ->
                Text(ln.text, Modifier.padding(vertical = 8.dp), style = MaterialTheme.typography.titleLarge,
                    color = if (i == idx || ln.ms < 0) Color.White else Color.DarkGray)
            }
        }
    }
}

@Composable
fun Spectrum() {
    val id = PlayerHolder.player.audioSessionId
    var mags by remember { mutableStateOf(FloatArray(32)) }
    DisposableEffect(id) {
        val v = try {
            Visualizer(id).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, r: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray, r: Int) {
                        val n = 32; val step = (fft.size / 2 - 1) / n; val o = FloatArray(n)
                        for (i in 0 until n) {
                            var sum = 0f
                            for (j in 0 until step) { val k = 2 * (1 + i * step + j); sum += hypot(fft[k].toFloat(), fft[k + 1].toFloat()) }
                            o[i] = (sum / step / 128f).coerceIn(0f, 1f)
                        }
                        mags = o
                    }
                }, Visualizer.getMaxCaptureRate() / 2, false, true)
                enabled = true
            }
        } catch (e: Exception) { null }
        onDispose { v?.enabled = false; v?.release() }
    }
    Canvas(Modifier.fillMaxWidth().height(260.dp)) {
        val w = size.width / mags.size
        mags.forEachIndexed { i, m ->
            val h = size.height * m.coerceAtLeast(0.02f)
            drawRoundRect(Brush.verticalGradient(listOf(Accent, Color(0xFFFF9F0A))), Offset(i * w + 2f, size.height - h),
                Size(w - 4f, h), CornerRadius(6f, 6f))
        }
    }
}

@Composable
fun EqDialog(onClose: () -> Unit) {
    val e = PlayerHolder.eq
    AlertDialog(onDismissRequest = onClose, confirmButton = { TextButton(onClose) { Text("Done") } }, title = { Text("Equalizer") }, text = {
        if (e == null) Text("Start playback first.") else Column(Modifier.verticalScroll(rememberScrollState())) {
            var on by remember { mutableStateOf(e.enabled) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Enabled", Modifier.weight(1f)); Switch(on, { on = it; e.enabled = it }) }
            val r = e.bandLevelRange
            val lv = remember { mutableStateListOf<Float>().apply { for (b in 0 until e.numberOfBands) add(e.getBandLevel(b.toShort()).toFloat()) } }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in 0 until e.numberOfPresets) AssistChip({
                    e.usePreset(i.toShort())
                    for (b in 0 until e.numberOfBands) { val l = e.getBandLevel(b.toShort()); lv[b] = l.toFloat(); PlayerHolder.levels[b] = l }
                }, { Text(e.getPresetName(i.toShort())) })
            }
            for (b in 0 until e.numberOfBands) {
                Text("${e.getCenterFreq(b.toShort()) / 1000} Hz", style = MaterialTheme.typography.bodySmall)
                Slider(lv[b], { lv[b] = it; e.setBandLevel(b.toShort(), it.toInt().toShort()); PlayerHolder.levels[b] = it.toInt().toShort() },
                    valueRange = r[0].toFloat()..r[1].toFloat())
            }
        }
    })
}
