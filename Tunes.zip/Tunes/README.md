# Tunes – iTunes-style Android music player
Open this folder in Android Studio (Koala+), let Gradle sync, run on your phone (Android 8+).
- Library from MediaStore, Songs + Albums tabs, full-size album art (embedded art, up to 1600px)
- Auto lyrics: synced lyrics from LRCLIB, cached offline, highlighted in time
- Audio: Media3/ExoPlayer, float PCM output for hi-res files, audio focus, headset-unplug pause
- System Equalizer with presets + per-band sliders; live FFT spectrum visualizer
- LDAC/LHDC: negotiated by Android + your headphones. Enable in Settings > Developer options > Bluetooth audio codec.
